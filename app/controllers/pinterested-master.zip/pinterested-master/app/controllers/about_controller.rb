class AboutController < ApplicationController
end
